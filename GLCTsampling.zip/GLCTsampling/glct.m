function [Fa,Va,F,V,Lambda] = glct(G,k1,k2,sigma,a)
% Graph linear canonical transform    

% Usage:  [Fa,Va,F,V,Lambda] = glct(G,k1,k2,sigma,a)
 
% Input parameter (G is required):
% G: a garph.
% k1, k2: graph chirp multiplication parameters.
% sigma: graph scaling transform parameter.
% a: graph fractional Fourier transform parameter.
 
% Output parameters:
% Fa: graph linear canonical transform matrix.
% Va: graph linear canonical transform inverse matrix. 
% F: graph Fourier transform matrix.
% V: graph Fourier transform inverse matrix. 
% Lambda: eigenvalue of the adjacency matrix.

% Example: G = gsp_ring(64); k1=0.5; k2=1; sigma=2; a=1;
% [Fa,Va,F,V,Lambda] = glct(G,k1,k2,sigma,a);
 
% References:
% Y. Zhang and B. Z. Li, "Discrete linear canonical transform on graphs,"
% Digit. Signal Process. 135 (2023) 103934.

% Copyright (c) 2024 Y. Zhang and B. Z. Li

%% parameters
 N = G.N;
 A = G.W;
[V,Lambda] = eig(full(A)); % Decompose the adjacency matrix
[~,Index] = sort(diag(Lambda),'descend'); % Sorting
V = V(:,Index);
%% Obtain GFRFT and CM stage matrices
F = inv(V);
 [P,J] = eig(F); % Decompose the GFT matrix
    [~,Index] = sort(diag(J),'descend'); % Sorting
    J = J(Index,Index);
    P = P(:,Index);
    Xi=k1*(1:N)'+k2;% Obtain chirp parameters, where k1 and k2 correspond to l and f in the paper
%% Obtain scaling transform stage matrices
[VA,LA]=eig(full(A/sigma));
    [~,Index] = sort(diag(LA),'descend'); % Sorting
    VA = VA(:,Index);
FA = inv (VA);
[PA,JA] = eig(FA); % Decompose the GFT matrix after scaling transform
    [~,Index] = sort(diag(JA),'descend'); % Sorting
    JA = JA(Index,Index);
    PA = PA(:,Index);
%% Obtain graph linear canonical transform matrix  
    Fa = diag(diag(J).^Xi)*PA*diag(diag(J).^a)/P;
    Va = inv(Fa);
end