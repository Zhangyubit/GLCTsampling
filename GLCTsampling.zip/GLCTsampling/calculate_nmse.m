function NMSE = calculate_nmse(original_signal,recovered_signal)
%This function is used to calculate the normalized mean square error (MSE).
%The smaller the value, the better the signal reconstruction quality.
%original_signal: the original signal.
%recovered_signal: the recovered signal.
    % Calculating NMSE
    numerator = norm(original_signal - recovered_signal, 2)^2;
    denominator = norm(original_signal, 2)^2;

    % Preventing the denominator from being zero
    if denominator == 0
        NMSE = NaN;
    else
        NMSE = numerator / denominator;
    end
end