% Clear workspace, command window, and figures
% References:
% Y. Zhang and B. Z. Li, "Discrete linear canonical transform on graphs:
% Uncertainty principle and sampling" 

% Copyright (c) 2024 Y. Zhang and B. Z. Li

clc;
clear;
gsp_start; % Start GSP toolbox
addpath('SampMethods');
addpath('data');

%%% Test the impact of GLCT matrix on optimal sampling operator selection
%% Select the underlying graph
G = gsp_rome(); % Using rome traffic flow network graph

%% Graph information
xy = G.coords; % Coordinates array
Px = G.coords(:,1); % x-coordinates
Py = G.coords(:,2); % y-coordinates
N = G.N; % Number of vertices
A = G.W; % Adjacency matrix

%% Graph Linear Canonical Transform (GLCT)
k1 = 0.5; k2 = 0.7; sigma = N; a = 0.9;
[OM, VM, O, V, ~] = glct(G, k1, k2, sigma, a); % Compute GLCT matrix
[Oa, Va, ~, ~, ~] = glct(G, 0, 0, 1, a); % Compute fractional Fourier matrix

%% ======== Graph Signal ========= %%
load x  % Load a signal from a file 
% (here we assume there is already a signal file named x)
% Bandlimit the signal
K = 50; % Spectral bandwidth
S = 50; % Vertex domain bandwidth
filter = ones(1, N);
filter((K + 1):N) = 0; % Set spectral bandwidth
Filter = diag(filter);
H = VM * Filter * OM; % GLCT matrix with bandpass filter
y = H * x; % Bandlimited signal
haty = OM * y; % GLCT of the signal

%% ======== GFT based on Laplacian ========= %%
D_A = diag(sum(A, 2));
L = D_A - A;
[V_L, Lambda_L] = eig(full(L)); % Decompose the Laplacian
[~, Index] = sort(diag(Lambda_L), 'descend'); % Sort eigenvalues
V_L = V_L(:, Index); % Reorder eigenvectors
F = inv(V_L); % GFT matrix based on Laplacian

%% Compute spectral bandwidth operators
VMk = VM(:, 1:K); % First K columns of GLCT matrix
Vak = Va(:, 1:K); % First K columns of fractional Fourier matrix
Vk = V(:, 1:K); % First K columns of GFT matrix
V_Lk = V_L(:, 1:K); % First K columns of Laplacian GFT matrix
Filter = diag([ones(K, 1); zeros(N - K, 1)]); % Construct bandpass filter
BM = VM * Filter * OM; % GLCT bandpass localization operator
Ba = Va * Filter * Oa;
B = V * Filter * O;
B_L = V_L * Filter * F;

% Greedy algorithm handles and identifiers
algorithms = {@greedyMinPinvSig, @greedyMaxParallVolume, @greedyMinFrobNorm, ...
              @greedyMaxSingularValue, @greedyMaxSigMin, @greedyMaxEnergy, @greedyMaxVertex};
algorithm_names = {'MinPinvSig', 'MaxParallVolume', 'MinFrobNorm', ...
                   'MaxSingularValue', 'MaxSigMin', 'MaxEnergy', 'MaxVertex'};

% Initialize NMSE matrix
NMSE = zeros(7, 4);

% Run all greedy algorithms and store NMSE
for i = 1:length(algorithms)
    if strcmp(algorithm_names{i}, 'MaxEnergy')
        sel1 = algorithms{i}(Vk, S, haty);
        sel2 = algorithms{i}(Vak, S, haty);
        sel3 = algorithms{i}(VMk, S, haty);
        sel4 = algorithms{i}(V_Lk, S, haty);
    elseif strcmp(algorithm_names{i}, 'MaxVertex')
        sel1 = algorithms{i}(Vk, S, y);
        sel2 = algorithms{i}(Vak, S, y);
        sel3 = algorithms{i}(VMk, S, y);
        sel4 = algorithms{i}(V_Lk, S, y);
    else
        sel1 = algorithms{i}(Vk, S);
        sel2 = algorithms{i}(Vak, S);
        sel3 = algorithms{i}(VMk, S);
        sel4 = algorithms{i}(V_Lk, S);
    end
    
    % Signal reconstruction
    [~, ~, sig_rec1, ~] = signalrec(sel1, B, y);
    [~, ~, sig_rec2, ~] = signalrec(sel2, Ba, y);
    [~, ~, sig_rec3, ~] = signalrec(sel3, BM, y);
    [~, ~, sig_rec4, ~] = signalrec(sel4, B_L, y);
    
    % Compute NMSE
    NMSE(i, 1) = calculate_nmse(y, sig_rec1); % Based on GFT
    NMSE(i, 2) = calculate_nmse(y, sig_rec2); % Based on GFRFT
    NMSE(i, 3) = calculate_nmse(y, sig_rec3); % Based on GLCT
    NMSE(i, 4) = calculate_nmse(y, sig_rec4); % Based on Laplacian GFT
end

% Display NMSE matrix
disp('NMSE Matrix:');
disp(NMSE);

%% Plotting
% Using greedyMinPinvSig for plotting
sel1 = greedyMinPinvSig(Vk, S);
sel2 = greedyMinPinvSig(Vak, S);
sel3 = greedyMinPinvSig(VMk, S);
sel4 = greedyMinPinvSig(V_Lk, S);

% Signal reconstruction
[~, ~, sig_rec1, ~] = signalrec(sel1, B, y);
[~, ~, sig_rec2, ~] = signalrec(sel2, Ba, y);
[~, ~, sig_rec3, ~] = signalrec(sel3, BM, y);
[~, ~, sig_rec4, ~] = signalrec(sel4, B_L, y);

% Original signal
figure();
gsp_plot_signal(G, real(y)); 
title('Original Signal');

% 1.1 GFT sampling points
figure(); 
gplot(A, xy);
hold on
scatter(Px, Py, 30, 'w', 'filled', 'MarkerEdgeColor', 'k');
hold on
scatter(Px(sel1), Py(sel1), 30, 'sk', 'filled', 'MarkerEdgeColor', 'k');
colormap(jet);
title('GFT Sampling Points');

% 1.2 Reconstructed signal using GFT
figure();
gsp_plot_signal(G, real(sig_rec1)); 
title('Reconstructed Signal using GFT');

% 2.1 GFRFT sampling points
figure(); 
gplot(A, xy);
hold on
scatter(Px, Py, 30, 'w', 'filled', 'MarkerEdgeColor', 'k');
hold on
scatter(Px(sel2), Py(sel2), 30, 'sk', 'filled', 'MarkerEdgeColor', 'k');
colormap(jet);
title('GFRFT Sampling Points');

% 2.2 Reconstructed signal using GFRFT
figure();
gsp_plot_signal(G, real(sig_rec2)); 
title('Reconstructed Signal using GFRFT');

% 3.1 GLCT sampling points
figure(); 
gplot(A, xy);
hold on
scatter(Px, Py, 30, 'w', 'filled', 'MarkerEdgeColor', 'k');
hold on
scatter(Px(sel3), Py(sel3), 30, 'sk', 'filled', 'MarkerEdgeColor', 'k');
colormap(jet);
title('GLCT Sampling Points');

% 3.2 Reconstructed signal using GLCT
figure();
gsp_plot_signal(G, real(sig_rec3)); 
title('Reconstructed Signal using GLCT');

% 4.1 Laplacian-based GFT sampling points
figure(); 
gplot(A, xy);
hold on
scatter(Px, Py, 30, 'w', 'filled', 'MarkerEdgeColor', 'k');
hold on
scatter(Px(sel4), Py(sel4), 30, 'sk', 'filled', 'MarkerEdgeColor', 'k');
colormap(jet);
title('Laplacian-based GFT Sampling Points');

% 4.2 Reconstructed signal using Laplacian-based GFT
figure();
gsp_plot_signal(G, real(sig_rec4)); 
title('Reconstructed Signal using Laplacian-based GFT');