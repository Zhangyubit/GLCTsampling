function sel = greedyMaxVertex(VMf, M, x)
% This function selects M nodes by maximizing the signal energy in the time domain.
%
% Inputs:
% VMf: The feature matrix of the signal (not used in this method)
% M: The number of nodes to be selected
% x: The signal in the time domain
%
% Outputs:
% sel: The set of selected nodes

% References:
% Y. Zhang and B. Z. Li, "Discrete linear canonical transform on graphs:
% Uncertainty principle and sampling" 

% Copyright (c) 2024 Y. Zhang and B. Z. Li

% Initialize the set of selected nodes as an empty array
sel = [];
% Get the total number of nodes
N = size(VMf, 1);

% Compute the signal energy for each node
energy = abs(x).^2;

% Loop to select M nodes
for cont2 = 1:M
    % Initialize a weight vector to store the weight of each node
    b = zeros(N, 1);

    % Iterate over all nodes
    for cont3 = 1:N
        % If the node is not already in the selected set
        if sum(find(cont3 == sel)) == 0
            % Record the signal energy of the node
            b(cont3) = energy(cont3);
        else
            % If the node is already in the selected set, set its weight to negative infinity
            b(cont3) = -inf;
        end
    end

    % Find the node with the maximum signal energy
    [m, pos] = max(b);
    % Add the node with the maximum signal energy to the selected set
    sel = [sel, pos];
end
end

