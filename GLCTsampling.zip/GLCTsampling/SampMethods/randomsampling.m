function [sample, row, col] = randomsampling(VMf, M)
% This function performs random sampling from a matrix.
%
% Inputs:
% VMf: The input matrix
% M: The desired number of samples
%
% Outputs:
% sample: The sampled elements from the input matrix
% row: The row indices of the sampled elements
% col: The column indices of the sampled elements

% Get the number of rows and columns in the input matrix
[numRows, numCols] = size(VMf);
% Calculate the total number of elements in the matrix
numElements = numRows * numCols;

% Generate random linear indices
linearIndices = randperm(numElements, M);

% Convert linear indices to row and column indices
[row, col] = ind2sub([numRows, numCols], linearIndices);

% Extract the sampled elements from the input matrix
sample = VMf(linearIndices);
end