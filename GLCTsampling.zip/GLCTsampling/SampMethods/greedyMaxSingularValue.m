function sel = greedyMaxSingularValue(VMf, M)
% This function selects M nodes by maximizing the sum of the squared singular values
% of the submatrix formed by the selected nodes' rows in the feature matrix VMf.
%
% Inputs:
% VMf: The feature matrix of the signal
% M: The number of nodes to be selected
%
% Outputs:
% sel: The set of selected nodes

% References:
% Y. Zhang and B. Z. Li, "Discrete linear canonical transform on graphs:
% Uncertainty principle and sampling" 

% Copyright (c) 2024 Y. Zhang and B. Z. Li

% Initialize the set of selected nodes as an empty array
sel = [];
% Get the total number of nodes
N = size(VMf, 1);

% Loop to select M nodes
for cont2 = 1:M
    % Initialize a weight vector to store the weight of each node
    b = zeros(N, 1);

    % Iterate over all nodes
    for cont3 = 1:N
        % If the node is not already in the selected set
        if sum(find(cont3 == sel)) == 0
            % Add the current node to the selected set
            set = [sel, cont3];
            % Compute the singular values of the submatrix formed by the selected nodes
            singularValues = svd(VMf(set, :));
            % Calculate the sum of the squared singular values
            b(cont3) = sum(singularValues.^2);
        else
            % If the node is already in the selected set, set its weight to negative infinity
            b(cont3) = -inf;
        end
    end

    % Find the node with the maximum weight
    [m, pos] = max(b);
    % Add the node with the maximum weight to the selected set
    sel = [sel, pos];
end
end
