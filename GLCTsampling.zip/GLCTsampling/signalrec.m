function [D,check,sig_rec,sig_s] = signalrec(sel,B,y) 
% Usage:  [D,check,sig_rec,sig_s] = signalrec(sel,B,y) 

% Input parameter:
% sel: Sampling set.
% B: Perfect localization matrix in the GLCT domain.
% y: Original signal after M-bandlimited.

% Output parameters:
% D: Sampling matrix.
% check: Check whether perfect localization is satisfied.
% sig_rec: Reconstructed signal.
% sig_s: Sampled signal.

% References:
% Y. Zhang and B. Z. Li, "Discrete linear canonical transform on graphs:
% Uncertainty principle and sampling" 

% Copyright (c) 2024 Y. Zhang and B. Z. Li

N=size(B,1);
d=zeros(N,1);
d(sel)=1;
D=diag(d);
Dbar=eye(N)-D;
check=norm(Dbar*B);
sig_s=D*y;   %sampled signal
sig_rec=inv(eye(N)-Dbar*B)*sig_s;
end