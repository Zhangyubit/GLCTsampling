function [G]=gsp_rome(N,k)
%GSP_ROME  Initialize a rome traffic flow network graph

%   Usage:  G = gsp_rome(N);
%           G = gsp_rome(N,k);
%           G = gsp_rome();
%   Example:
%
%          G = gsp_rome();
%          gsp_plot_graph(G);
%          input signal y
%          gsp_plot_signal(G,y);

% References:
% Y. Zhang and B. Z. Li, "Discrete linear canonical transform on graphs:
% Uncertainty principle and sampling" 

% We thank Mikhail Tsitsvero, Sergio Barbarossa, and Paolo Di Lorenzo for
% their support and help.

if nargin < 1
   N=376;
end

if nargin < 2
    k = 1;
end

G.N=N;

if k>N/2
    error('Too many neighbors requested');
end

%Download Data
addpath('data');
load A
load xy

% Create weighted adjancency matrix 
G.W = A;

% Create coordinates

G.coords = xy;
G.plotting.limits=[14,874,14,661];


if k==1 
    G.type = 'rome';
else
    G.type = 'k-rome';
end

G = gsp_graph_default_parameters(G);

end

