% References:
% Y. Zhang and B. Z. Li, "Discrete linear canonical transform on graphs:
% Uncertainty principle and sampling" 

% Copyright (c) 2024 Y. Zhang and B. Z. Li

clear
clc
close all

% Initialize the GSP toolbox
gsp_start

% Generate a Swiss roll graph with 256 nodes
G = gsp_swiss_roll(256);
xy = G.coords; % Coordinates array
Px = G.coords(:,1); % X-axis coordinates
Py = G.coords(:,2); % Y-axis coordinates
N = G.N; % Number of vertices
A = G.W; % Adjacency matrix

% Load input signal
load x  % Signal
x = x(1:N);

%% Graph linear canonical transform 
% Set parameters for the Graph Linear Canonical Transform (GLCT)
k1 = 0.5; 
k2 = 1; 
sigma = N; 
a = 0.8;
[OM, VM, ~, V, Lambda] = glct(G, k1, k2, sigma, a); % Compute GLCT
AM = VM * Lambda * OM;

% Filter to make the signal band-limited
filter = ones(1, N);
filter(33:N) = 0; % Frequency bandwidth
Filter = diag(filter);
H = VM * Filter * OM; % Construct band-limited filter
y = H * x; % Apply filter to the signal
yreal = real(H * y); % Get the real part of the filtered signal

% Plot the filtered signal
figure()
gsp_plot_signal(G, yreal);

% Apply GLCT to the signal
haty = OM * y;
figure()
hold on
plot(abs(haty))
grid on
xlabel('Eigenvalue indexes')
ylabel('GLCT coefficients (absolute value)')

%% Sampling and recovery
F = 32; % Frequency bandwidth

VMf = VM(:,1:F); % Select the first F columns of VM
Filter = diag([ones(F,1); zeros(N-F,1)]);
B = VM * Filter * OM;

% Define sampling points
S = [32, 64, 96, 128, 160, 192, 224, 256];

% Store NMSE values for different S
num_S = length(S);
num_cases = 8; % Number of sampling methods
nmse_values_all = zeros(num_S, num_cases);

% Loop over different S values
for S_idx = 1:num_S
    current_S = S(S_idx);

    % Sampling methods
    [~, sel1, ~] = randomsampling(VMf, current_S); % Random sampling
    sel2 = greedyMinPinvSig(VMf, current_S);  % Minimize the smallest singular value of pinv(VMf)
    sel3 = greedyMaxSingularValue(VMf, current_S);  % Maximize the largest singular value of VMf
    sel4 = greedyMaxSigMin(VMf, current_S);  % Maximize the smallest singular value of VMf
    sel5 = greedyMaxParallVolume(VMf, current_S);  % Maximize the volume of the parallelepiped formed by columns of VMf
    sel6 = greedyMinFrobNorm(VMf, current_S);  % Minimize the Frobenius norm of pinv(VMf)
    sel7 = greedyMaxVertex(VMf, current_S, y); % Maximize vertex energy
    sel8 = greedyMaxEnergy(VMf, current_S, haty); % Maximize spectral energy
    sel = {sel1, sel2, sel3, sel4, sel5, sel6, sel7, sel8};  % Store the selections

    % Store NMSE values for different selections
    nmse_values = zeros(num_cases, 1);

    % Loop over different selections
    for case_idx = 1:num_cases
        current_sel = sel{case_idx};
        d = zeros(N, 1);
        d(current_sel) = 1;
        D = diag(d);
        Dbar = eye(N) - D;

        % Generate sampled signal
        r = D * y;

        % Signal recovery
        sig_rec = inv(eye(N) - Dbar * B) * r;

        % Calculate NMSE
        nmse_values(case_idx) = calculate_nmse(y, sig_rec);
    end

    % Store NMSE values for the current S
    nmse_values_all(S_idx, :) = nmse_values;
end

%% Plot comparison of NMSE values
colors = {[0, 0, 0], [0, 0, 1], [0, 1, 0], [1, 0, 0], [0, 1, 1], [1, 0, 1], [1, 1, 0], [1, 0.5, 0]}; 
markers = {'d', 'o', '+', '*', 'x', 's', '^', 'v'};
line_width = 2.5;
marker_size = 8;
logNMSE = log10(nmse_values_all);

% Plot the lines
figure();
for col = 1:size(logNMSE, 2)
    plot(32:32:256, logNMSE(:, col), 'Color', colors{col}, 'Marker', markers{col}, 'LineStyle', '-', 'LineWidth', line_width, 'MarkerSize', marker_size);
    hold on;
end
title('Sampling algorithms comparison');
xlabel('Number of samples');
ylabel('Value of log10(NMSE)');
legend('Random', 'MinPinv', 'MaxSig', 'MaxSigMin', 'MaxVol', 'MinFro', 'MaxVertex', 'MaxSpec', 'Location', 'Best', 'FontSize', 15);
xlim([32, 256]);
ylim([-Inf, -18]);
yticks((-32:2:-18));
yticklabels({'-32', '-30', '-28', '-26', '-24', '-22', '-20', '-18'});
hold off;

%% Example of signal recovery using optimal sampling
ex_sel6 = greedyMaxSigMin(VMf, 4); 
[D, check, ex_sig_rec, ~] = signalrec(ex_sel6, B, y);

% Plot the recovered signal
figure()
gsp_plot_signal(G, real(ex_sig_rec));

% Plot the sampling points on the graph
figure()
gplot(A, xy)
hold on
scatter(Px, Py, 30, 'w', 'filled', 'MarkerEdgeColor', 'k')
hold on
scatter(Px(ex_sel6), Py(ex_sel6), 30, 'sk', 'filled', 'MarkerEdgeColor', 'k')
colormap(jet)